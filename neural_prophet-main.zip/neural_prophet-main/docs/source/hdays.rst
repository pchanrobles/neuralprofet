Core Module Documentation
==========================

.. automodule:: neuralprophet.hdays
   :members: