Core Module Documentation
==========================

.. automodule:: neuralprophet.time_net
   :members: