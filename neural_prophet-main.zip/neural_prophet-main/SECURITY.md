# Security Policy

## Supported Versions

This project supports but the most recent version with security updates.

## Reporting a Vulnerability

Feel free to report any vulnerabilities.

Please also let us know if you have any security concerns for your particular use of this forecasting tool. 

